<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-50 text-gray-800 flex h-screen overflow-hidden">

    
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="flex-1 flex flex-col">
        
        <header class="bg-white shadow flex items-center justify-between px-6 py-3">

            <h1 class="text-xl font-semibold text-gray-700"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>

            <div class="flex items-center gap-6">

                
                <div class="relative">
                    <button id="notificationButton" class="relative">
                        
                        <svg class="w-7 h-7 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M15 17h5l-1.4-1.4a2 2 0 01-.6-1.4V11a7 7 0 10-14 0v3.2c0 .5-.2 1-.6 1.4L3 17h5m7 0a3 3 0 11-6 0h6z" />
                        </svg>

                        
                        <?php $role = Auth::user()->role; ?>

                        
                        <?php if($role === 'admin' && ($pendingCount + $requestBillingCount + ($newParentCount ?? 0)) > 0): ?>
                            <span class="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold
                            w-5 h-5 flex items-center justify-center rounded-full">
                                <?php echo e($pendingCount + $requestBillingCount + ($newParentCount ?? 0)); ?>

                            </span>
                        <?php endif; ?>

                        
                        <?php if($role === 'orang_tua' && $notificationCount > 0): ?>
                            <span id="notificationBadge"
                                class="absolute -top-1 -right-1 bg-red-600 text-white text-xs font-bold
                                w-5 h-5 flex items-center justify-center rounded-full">
                                <?php echo e($notificationCount); ?>

                            </span>
                        <?php endif; ?>
                    </button>

                    
                    <div id="notificationDropdown"
                        class="hidden absolute right-0 mt-2 w-80 bg-white shadow-lg border rounded-xl overflow-hidden z-50">

                        <div class="px-4 py-2 font-semibold border-b bg-gray-50">
                            Notifikasi
                        </div>

                        
                        <?php if($role === 'admin'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $combinedNotif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                
                                <?php if($item['type'] === 'pending'): ?>
                                    <a href="<?php echo e(route('admin.iuran.index', ['parent' => $item['parent']->id])); ?>"
                                    class="block px-4 py-3 hover:bg-gray-100 border-b">
                                        <p class="font-medium">
                                            <?php echo e($item['parent']->userProfile->nama_lengkap ?? $item['parent']->name); ?>

                                        </p>
                                        <p class="text-sm text-gray-600">
                                            <?php echo e($item['total_transaksi']); ?> pembayaran siswa pending
                                        </p>
                                        <p class="text-sm font-bold text-gray-800">
                                            Rp <?php echo e(number_format($item['total_nominal'], 0, ',', '.')); ?>

                                        </p>
                                    </a>
                                <?php endif; ?>

                                
                                <?php if($item['type'] === 'request'): ?>
                                    <a href="<?php echo e(route('admin.iuran.requests')); ?>"
                                    class="block px-4 py-3 hover:bg-gray-100 border-b">
                                        <p class="font-medium"><?php echo e($item['title']); ?></p>
                                        <p class="text-sm text-gray-600"><?php echo e($item['message']); ?></p>
                                        <p class="text-xs text-gray-400">
                                            <?php echo e($item['created_at']->diffForHumans()); ?>

                                        </p>
                                    </a>
                                <?php endif; ?>

                                
                                <?php if($item['type'] === 'new_parent'): ?>
                                    <a href="<?php echo e(route('admin.pembayaran.index')); ?>"
                                    class="block px-4 py-3 hover:bg-gray-100 border-b">
                                        <p class="font-medium">
                                            Parent Baru: <?php echo e($item['parent']->userProfile->nama_lengkap ?? $item['parent']->name); ?>

                                        </p>
                                        <p class="text-sm text-gray-600">Menunggu verifikasi</p>
                                        <p class="text-xs text-gray-400">
                                            <?php echo e($item['created_at']->diffForHumans()); ?>

                                        </p>
                                    </a>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="px-4 py-3 text-gray-500 text-sm">Tidak ada notifikasi</p>
                            <?php endif; ?>
                        <?php endif; ?>

                        
                        <?php if($role === 'orang_tua'): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $approvedNotification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(route('parent.iuran.index')); ?>"
                                class="block px-4 py-3 hover:bg-gray-100 border-b">

                                    <p class="font-medium">
                                        Pembayaran bulan <?php echo e($notif->data['bulan']); ?> telah diverifikasi
                                    </p>

                                    <p class="text-sm font-bold text-gray-800">
                                        Rp <?php echo e(number_format($notif->data['amount'], 0, ',', '.')); ?>

                                    </p>

                                    <p class="text-xs text-gray-400">
                                        <?php echo e($notif->created_at->diffForHumans()); ?>

                                    </p>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="px-4 py-3 text-gray-500 text-sm">Tidak ada notifikasi</p>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>

                
                <span class="text-gray-600 font-medium"><?php echo e(Auth::user()->name ?? 'User'); ?></span>
                <img src="<?php echo e(avatar_url(Auth::user())); ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover">
            </div>
        </header>

        
        <main class="flex-1 overflow-y-auto p-6">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.0/flowbite.min.js"></script>
    <script>
        const btn = document.getElementById('notificationButton');
        const dropdown = document.getElementById('notificationDropdown');

        btn.addEventListener('click', () => {
            dropdown.classList.toggle('hidden');
        });

        document.addEventListener('click', (e) => {
            if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.add('hidden');
            }
        });
    </script>
    
</body>
</html>
<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/layouts/app.blade.php ENDPATH**/ ?>