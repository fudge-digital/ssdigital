

<?php $__env->startSection('title', 'Daftar Orang Tua'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h2 class="text-2xl font-bold mb-6">Daftar Orang Tua & Promo</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-200 text-green-800 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full border text-left">
        <thead>
            <tr class="bg-gray-100 text-sm">
                <th class="p-2 border">No.</th>
                <th class="p-2 border">Nama Parent</th>
                <th class="p-2 border">Jumlah Siswa</th>
                <th class="p-2 border">Promo Aktif</th>
                <th class="p-2 border">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-sm">
                    <td class="p-2 border"><?php echo e($loop->iteration); ?></td>
                    <td class="p-2 border"><?php echo e($parent->name); ?></td>
                    <td class="p-2 border"><?php echo e($parent->children_count); ?></td>

                    
                    <td class="p-2 border">
                        <?php if($parent->promo_type === null || $parent->promo_type === 'none'): ?>
                            <span class="px-2 py-1 bg-gray-400 text-white rounded text-sm">Tidak Ada</span>
                        <?php elseif($parent->promo_type === 'sibling'): ?>
                            <span class="px-2 py-1 bg-blue-600 text-white rounded text-sm">Sibling</span>
                        <?php elseif($parent->promo_type === 'sponsor'): ?>
                            <span class="px-2 py-1 bg-green-600 text-white rounded text-sm">Sponsor</span>
                        <?php elseif($parent->promo_type === 'beasiswa'): ?>
                            <span class="px-2 py-1 bg-purple-600 text-white rounded text-sm">Beasiswa</span>
                        <?php endif; ?>
                    </td>

                    <td class="p-2 border">
                        
                        <?php if($parent->children_count > 1): ?>
                            <form method="POST" action="<?php echo e(route('parents.updatePromo', $parent->id)); ?>">
                                <?php echo csrf_field(); ?>

                                <select name="promo_type" class="border rounded px-2 py-1 text-sm">
                                    <?php $__currentLoopData = ['none','sibling','sponsor','beasiswa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="text-sm capitalize" value="<?php echo e($type); ?>" <?php echo e($parent->promo_type === $type ? 'selected' : ''); ?>>
                                            <?php echo e(strtoupper($type)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit"
                                    class="px-3 py-1 bg-blue-600 text-white rounded text-sm ml-2">
                                    Update
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="text-gray-500 text-sm italic">Tidak Eligible</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($parents->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/admin/parent/index.blade.php ENDPATH**/ ?>