<?php echo e($slot); ?>

<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>