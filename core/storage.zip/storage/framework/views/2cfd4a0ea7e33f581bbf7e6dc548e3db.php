

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-6">

    <div class="mb-6 flex justify-between content-center items-center">
        <div>
            <h1 class="text-2xl font-bold"><?php echo e($student->name); ?></h1>
        </div>
        <div>
            <p class="text-sm">
                <a href="<?php echo e(backRoute()); ?>" class="flex items-center gap-2 px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded text-sm transition">
                    <i class="fa-solid fa-arrow-left mr-2"></i>Kembali
                </a>
            </p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div class="bg-white p-6 shadow rounded-lg">
            <div class="flex flex-row mb-4">
                <div class="basis-1/3">
                    
                    <div class="text-center text-sm">
                        <img src="<?php echo e(foto_url($student->profile->foto, 'siswa') ?? 'https://placehold.co/300x400'); ?>"
                        class="w-48 h-64 object-cover rounded-md mb-4 mx-auto">
                        <p class="text-center text-sm">NISS: <?php echo e($student->profile->niss ?? 'N/A'); ?></p>
                    </div> 
                </div>

                <div class="basis-2/3">
                    
                    <h2 class="text-2xl font-bold"><i class="fa-solid fa-shirt mr-2"></i><?php echo e($student->profile?->nomor_jersey ?? '0'); ?> - <?php echo e($student->profile->kelompok_umur); ?> <?php echo e($student->profile->jenis_kelamin_label); ?></h2>
                    <div class="grid grid-cols-3 gap-4 mt-4 mb-4 border-b pb-4">
                        <div>
                            <h2 class="text-gray-500 text-sm">Status</h2>
                            <p class="text-gray-700 font-medium text-left">
                                <?php if($student->profile->status === 'aktif'): ?>
                                    <span class="rounded text-blue-500 text-sm"><i class="fa-solid fa-circle-check mr-1"></i><?php echo e($student->profile->status_label); ?></span>
                                <?php elseif($student->profile->status === 'suspended'): ?>
                                    <span class="rounded text-red-500 text-sm"><i class="fa-solid fa-circle-minus mr-1"></i><?php echo e($student->profile->status_label); ?></span>
                                <?php elseif($student->profile->status === 'tidak_aktif'): ?>
                                    <span class="rounded text-yellow-500 text-sm"><i class="fa-solid fa-circle-xmark mr-1"></i><?php echo e($student->profile->status_label); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div>
                            <h2 class="text-gray-500 text-sm">Nama Panggilan</h2>
                            <p class="text-black font-medium text-sm"><?php echo e($student->profile->nama_panggilan ?? '-'); ?></p>
                        </div>
                        <div>
                            <h2 class="text-gray-500 text-sm">No WhatsApp</h2>
                            <?php if($student->profile->no_whatsapp): ?>
                            <p>
                                <a href="https://wa.me/<?php echo e(formatPhone($student->profile->no_whatsapp) ?? '0'); ?>" target="_blank" class="p-1 rounded text-white text-xs bg-green-500 font-medium hover:bg-green-200 hover:text-green-900 transition"><i class="fa-brands fa-whatsapp mr-2"></i><?php echo e($student->profile->no_whatsapp); ?></a>
                            </p>
                            <?php else: ?>
                            <p class="text-yellow-500 font-medium text-sm mt-1"><i class="fa-solid fa-circle-minus mr-2"></i>Belum Ada</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- <h3 class="text-lg font-semibold mb-2">Informasi Orang Tua</h3> -->
                    <?php $__empty_1 = true; $__currentLoopData = $student->parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="space-y-4 text-sm">
                        <div class="flex flex-row justify-between items-center">
                            <div>
                                <span class="font-medium">Nama Ayah:</span> <?php echo e($parent->profile->nama_ayah ?? '-'); ?>

                            </div>
                            <div>
                                <a href="#" class="px-2 py-1 capitalize rounded bg-gray-200 text-black-500 hover:bg-gray-500 hover:text-white transition"><i class="fa-solid fa-eye mr-1"></i>lihat</a>
                            </div>
                        </div>
                        <div class="flex flex-row justify-between items-center">
                            <div>
                                <span class="font-medium">Nama Ibu:</span> <?php echo e($parent->profile->nama_ibu ?? '-'); ?>

                            </div>
                            <div>
                                <a href="#" class="px-2 py-1 capitalize rounded bg-gray-200 text-black-500 hover:bg-gray-500 hover:text-white transition"><i class="fa-solid fa-eye mr-1"></i>lihat</a>
                            </div>
                        </div>
                        <div class="flex flex-row justify-between items-center">
                            <div>
                                <span class="font-medium">Kontak Darurat:</span> <?php echo e($parent->userProfile->phone ?? '-'); ?>

                            </div>
                            <div>
                                <a href="https://wa.me/<?php echo e(formatPhone($parent->userProfile->phone) ?? '#'); ?>" target="_blank" class="px-2 py-1 capitalize rounded bg-green-500 text-white hover:bg-green-200 hover:text-green-800 transition"><i class="fa-brands fa-whatsapp mr-1"></i>WhatsApp</a>
                            </div>
                        </div>
                        <div class="flex flex-row justify-between items-center">
                            <div>
                                <span class="font-medium">Alamat:</span> <p class="text-sm leading-8"><?php echo e($parent->userProfile->alamat ?? 'Belum Update'); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">Belum ada data orang tua terhubung.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="bg-white p-6 shadow rounded-lg">
            <h2 class="text-xl font-bold mb-4">Detail Informasi Siswa</h2>
            <table class="w-full text-left text-sm">
                <tr>
                    <th class="py-2 px-4 border-b">Tempat & Tanggal Lahir</th>
                    <td class="py-2 px-4 border-b"><?php echo e($student->profile->tempat_lahir ?? '-'); ?>, <?php echo e(formatDate($student->profile->tanggal_lahir)); ?></td>
                </tr>
                <tr>
                    <th class="py-2 px-4 border-b">Gender</th>
                    <td class="py-2 px-4 border-b"><?php echo e($student->profile->jenis_kelamin ?? '-'); ?></td>
                </tr>
                <tr>
                    <th class="py-2 px-4 border-b">Usia</th>
                    <td class="py-2 px-4 border-b"><?php echo e($student->profile->usia ?? '-'); ?> Tahun</td>
                </tr>
                <tr>
                    <th class="py-2 px-4 border-b">Asal Sekolah</th>
                    <td class="py-2 px-4 border-b"><?php echo e($student->profile->asal_sekolah ?? '-'); ?></td>
                </tr>
                <tr>
                    <th class="py-2 px-4 border-b">Size Jersey</th>
                    <td class="py-2 px-4 border-b">Size <?php echo e($student->profile->size_jersey ?? '-'); ?></td>
                </tr>
            </table>
            
            <?php echo $__env->make('siswa.partials.documents', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="flex justify-end">
        <a href="<?php echo e(route('siswa.edit', $student->id)); ?>" 
            class="inline-block px-4 py-2 bg-green-600 text-white text-sm rounded hover:bg-green-700 transition">
            <i class="fa-solid fa-pen-to-square mr-2"></i>Edit Profil Siswa
        </a>
    </div>

    
    <?php if(auth()->user()->isOrangTua()): ?>
        <?php echo $__env->make('partials.iuran-summary', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/siswa/show.blade.php ENDPATH**/ ?>