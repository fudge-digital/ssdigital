<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Verifikasi Pembayaran Pendaftaran</title>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Barlow', sans-serif;
            background-color: #f5f7fa;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            background: #ffffff;
            margin: 40px auto;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #0d5133;
            color: white;
            text-align: center;
            padding: 20px 30px;
        }
        .header img {
            height: 80px;
            margin-bottom: 5px;
        }
        .content {
            padding: 25px;
            font-size: 14px;
            line-height: 1.6;
        }
        .content h4 {
            margin-top: 20px;
            margin-bottom: 5px;
            font-size: 16px;
            font-weight: 600;
            color: #0d5133;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
        }
        .table th, .table td {
            border-bottom: 1px solid #e5e5e5;
            padding: 8px 5px;
            text-align: left;
            font-size: 13px;
        }
        .btn {
            background:#0d5133;
            color:white !important;
            padding:10px 20px;
            border-radius:30px;
            text-decoration:none;
            display:inline-block;
            margin-top:15px;
            font-weight:600;
        }
        .footer {
            background: #f1f1f1;
            text-align: center;
            font-size: 12px;
            padding: 15px;
            color: #555;
        }
    </style>
</head>

<body>
<div class="container">

    
    <div class="header">
        <img src="<?php echo e(asset('images/SATRIASILIWANGIFONT-1.png')); ?>" alt="Logo Klub">
        <h3>Pengajuan Verifikasi Pembayaran</h3>
    </div>

    
    <div class="content">
        <p>Halo Admin,</p>
        <p>Anda menerima pengajuan <strong><?php echo e($pembayaran->jenis === 'pendaftaran_baru' ? 'Pendaftaran Baru' : 'Registrasi Ulang'); ?></strong> dari orang tua berikut:</p>

        
        <h4>Data Orang Tua</h4>
        <ul>
            <li>Nama: <strong><?php echo e($pembayaran->user->name); ?></strong></li>
            <li>Email: <strong><?php echo e($pembayaran->user->email); ?></strong></li>
            <?php if($pembayaran->user->userProfile): ?>
                <li>No. HP: <strong><?php echo e($pembayaran->user->userProfile->phone ?? '-'); ?></strong></li>
            <?php endif; ?>
        </ul>

        
        <h4>Data Siswa</h4>
        <table class="table">
            <thead>
            <tr>
                <th>Nama</th>
                <th>Kelompok Umur</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pembayaran->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detail->nama_lengkap); ?></td>
                    <td><?php echo e($detail->siswaProfile->kelompok_umur ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <h4>Informasi Pembayaran</h4>
        <ul>
            <li>Jenis: <strong><?php echo e($pembayaran->jenis === 'pendaftaran_baru' ? 'Pendaftaran Baru' : 'Registrasi Ulang'); ?></strong></li>

            <?php if($pembayaran->jenis === 'pendaftaran_baru'): ?>
                <li>Total Pembayaran:
                    <strong>Rp <?php echo e(number_format($pembayaran->total_pembayaran, 0, ',', '.')); ?></strong>
                </li>
                <li>Bukti pembayaran telah ditambahkan oleh orang tua.</li>
            <?php else: ?>
                <li>Tidak ada pembayaran (Registrasi Ulang).</li>
            <?php endif; ?>
        </ul>

        
        <div style="text-align:center;">
            <a href="<?php echo e(url('/admin/pembayaran')); ?>" class="btn">Cek Dashboard</a>
        </div>

        <p style="margin-top:25px;">
            Mohon segera lakukan pengecekan dan verifikasi agar akun siswa dapat diproses.
        </p>
    </div>

    
    <div class="footer">
        &copy; <?php echo e(date('Y')); ?> Satria Siliwangi Basketball. Semua hak dilindungi.
    </div>

</div>
</body>
</html>
<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/emails/pending_registration.blade.php ENDPATH**/ ?>