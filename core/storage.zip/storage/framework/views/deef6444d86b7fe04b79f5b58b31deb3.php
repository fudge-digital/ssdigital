<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>