

<?php $__env->startSection('title', 'Dashboard Orang Tua'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6" x-data="{ openModal: false }">

    <h2 class="text-2xl font-bold mb-6 text-gray-800">
        Halo, <?php echo e($parent->name); ?> 👋
    </h2>

    
    <h4 class="col-span-full text-lg font-semibold text-gray-700 mb-4">Daftar Siswa Anda</h4>
    <div class="grid md:grid-cols-3 lg:grid-cols-3 gap-6 mb-10">
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white shadow-md rounded-2xl p-5 border">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="font-semibold text-lg"><?php echo e($student->name); ?></h3>
                    <span class="px-3 py-1 text-sm rounded-full 
                        <?php echo e($student->siswaProfile->status === 'aktif' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'); ?>">
                        <?php echo e(ucfirst($student->siswaProfile->status_label)); ?>

                    </span>
                </div>
                <p class="text-gray-600 text-sm mb-1">NISS: <?php echo e($student->profile->niss ?? '-'); ?></p>
                <p class="text-gray-600 text-sm mb-1">Email: <?php echo e($student->email); ?></p>
                <p class="text-gray-600 text-sm mb-1">Usia: <?php echo e($student->profile->usia); ?> tahun</p>
                <p class="text-gray-600 text-sm">Kategori Umur: <?php echo e($student->profile->kelompok_umur); ?> <?php echo e($student->profile->jenis_kelamin_label); ?></p>
                <div class="mt-4">
                    <?php if($student->siswaProfile->status !== 'tidak_aktif'): ?>
                        <a href="<?php echo e(route('siswa.show', $student->id)); ?>" class="bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded text-xs">
                            Detail Siswa
                        </a>
                    <?php else: ?>
                        <a href="#" class="bg-gray-600 hover:bg-gray-700 text-white py-2 px-3 rounded text-xs ml-2 cursor-not-allowed opacity-50">
                            Detail Siswa
                        </a>
                    <?php endif; ?>
                    
                    <?php if($student->siswaProfile->status !== 'tidak_aktif'): ?>
                        <a href="<?php echo e(route('siswa.edit', $student->id)); ?>" class="bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-xs ml-2">
                            Edit Data Siswa
                        </a>
                    <?php else: ?>
                        <a href="#" class="bg-gray-600 hover:bg-gray-700 text-white py-2 px-3 rounded text-xs ml-2 cursor-not-allowed opacity-50">
                            Edit Data Siswa
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Tidak ada data siswa yang terdaftar.</p>
        <?php endif; ?>
    </div>

    
    <?php if($student->siswaProfile->status === 'aktif'): ?>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <h2 class="col-span-full text-lg font-semibold text-gray-700 mb-4">Jadwal Latihan Bulan <?php echo e(now()->format('F Y')); ?></h2>
                <div class="bg-white shadow-lg rounded-xl px-4 py-4 pb-4">
                    <?php if($jadwalLatihan): ?>
                        <div class="prose max-w-none mb-6">
                            <?php echo $jadwalLatihan->content; ?>

                        </div>
                    <?php else: ?>
                        <p class="text-gray-500 text-center italic mb-6">
                            Belum ada jadwal diinformasikan
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <?php echo $__env->make('partials.iuran-summary', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>

    
    <?php if($nonActiveStudents->count() > 0): ?> 
        <h3 class="text-lg font-semibold mt-6">🔔 Informasi Pendaftaran</h3>
        <div class="grid md:grid-cols-3 lg:grid-cols-3 gap-6 mb-10">

            <div class="text-sm p-6 text-gray-900">
                <ol class="list-decimal list-inside space-y-2">
                    <li>
                        Biaya pendaftaran sebesar <strong>Rp 650.000,-</strong> untuk setiap siswa.
                        <ul class="list-disc list-inside ml-6 mt-1">
                            <li>Sudah termasuk iuran 1 bulan pertama</li>
                            <li>
                                Mendapatkan 1 set jersey latihan dengan jersey atasan reverse/bolak-balik
                                <a href="#" class="text-blue-500 underline">(lihat jersey latihan)</a>
                            </li>
                            <li>Mendapatkan Nomor Induk Satria Siliwangi (NISS) yang berlaku selamanya</li>
                            <li>Iuran perbulan adalah sebesar<strong>Rp 325.000,-</strong></li>
                        </ul>
                    </li>
                    <li>Silakan konfirmasi pembayaran dan unggah bukti pembayaran melalui formulir di samping.</li>
                    <li>Setelah pembayaran pendaftaran diverifikasi oleh admin, status siswa akan aktif dan mendapatkan NISS.</li>
                </ol>
            </div>
            
            
            <?php if($nonActiveStudents->count() > 0 && !$pembayaran): ?>
                <div class="bg-white border border-gray-200 rounded-2xl p-6 text-gray-900 mb-6">
                    <p class="font-semibold mb-3">Silakan pilih jenis pendaftaran:</p>

                    <form method="GET" action="<?php echo e(url()->current()); ?>" class="space-y-3">
                        <div class="flex items-center gap-3">
                            <input type="radio" name="regType" id="regReregister" value="Daftar_Ulang"
                                <?php echo e(request('regType') === 'Daftar_Ulang' ? 'checked' : ''); ?>>
                            <label for="regReregister" class="cursor-pointer font-medium text-sm">Registrasi Ulang</label>
                        </div>

                        <div class="flex items-center gap-3">
                            <input type="radio" name="regType" id="regNew" value="Pendaftaran_Baru"
                                <?php echo e(request('regType') === 'Pendaftaran_Baru' ? 'checked' : ''); ?>>
                            <label for="regNew" class="cursor-pointer font-medium text-sm">Pendaftaran Baru</label>
                        </div>

                        <button type="submit"
                            class="bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2 px-6 rounded-lg mt-4">
                            Lanjutkan
                        </button>
                    </form>

                    <div class="mt-4">
                        <ul class="text-xs list-disc">
                            <li>Daftar Ulang: Daftar ulang adalah untuk orang tua dan siswa yang sudah terdaftar sebagai anggota Satria Siliwangi Basketball dan ini wajib untuk pemuktahiran data Satria Siliwangi Basketball.</li>
                            <li>Pendaftaran Baru: Pendaftaran Baru adalah untuk orang tua dan siswa yang belum pernah terdaftar sebagai siswa Satria Siliwangi Basketball.</li>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            
            <?php if(request('regType') === 'Daftar_Ulang'): ?>
                <div class="bg-blue-100 border border-blue-200 text-sm rounded-2xl p-6 text-blue-900">
                    <p class="mb-3">
                        Anda telah melakukan <strong>Registrasi Ulang</strong>.
                    </p>
                    <p class="mb-3">
                        Pendaftaran ulang akan sudah dikirim ke admin untuk diverifikasi agar siswa bisa diaktifkan.
                    </p>

                    <?php if(!$pembayaran): ?>
                        
                        <form action="<?php echo e(route('parent.re-registration')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="regType" value="<?php echo e(request('regType')); ?>">
                            <input type="hidden" name="siswa_ids" value="<?php echo e($nonActiveStudents->pluck('id')->join(',')); ?>">
                            <button type="submit"
                                class="bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2 px-6 rounded-lg">
                                Kirim Registrasi Ulang ke Admin
                            </button>
                        </form>
                    <?php elseif($pembayaran->status === 'pending'): ?>
                        <div class="p-3 bg-green-200 text-green-800 rounded mb-4">
                            Registrasi ulang sudah dikirim ke admin. Mohon menunggu proses verifikasi 1x24 Jam.
                        </div>

                        <p class="mb-4">
                            Jika menurut anda proses verifikasi terlalu lama dan sudah lebih dari 1x24 jam, kemungkinan admin sedang sibuk. Silahkan kirim notifikasi Registrasi ulang melalui whatsapp di bawah ini. 
                        </p>

                        <?php
                            $message = "Halo Admin, ada pengajuan *Registrasi Ulang* dari Orang Tua: *$parent->name*"
                                . "\nJumlah Siswa: " . $nonActiveStudents->count()
                                . "\nNama Siswa: " . implode(', ', $nonActiveStudents->pluck('name')->toArray());
                        ?>

                        <a href="https://wa.me/62895606432020?text=<?php echo e(urlencode($message)); ?>" target="_blank"
                            class="inline-flex items-center gap-2 px-5 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg">
                            <i class="fa-brands fa-whatsapp text-lg"></i> WhatsApp Admin
                        </a>
                    <?php elseif($pembayaran->status === 'verified'): ?>
                        <div class="p-3 bg-green-200 text-green-800 rounded mb-4">
                            Registrasi ulang telah diverifikasi. Siswa siap diaktifkan.
                        </div>
                    <?php endif; ?>
                </div>

            
            <?php elseif(request('regType') === 'Pendaftaran_Baru'): ?>
                <?php if(!$pembayaran): ?>
                    <div class="bg-gray-100 border border-gray-200 text-sm rounded-2xl p-6 text-gray-900 mb-4">
                        Silakan lakukan pembayaran sejumlah yang tertera dibawah ke
                        <p class="py-2">
                            <strong>BCA a/n Satria Siliwangi<br>
                            No. Rek. 7773075176</strong>
                        </p>
                        dan unggah bukti pembayaran pendaftaran untuk melanjutkan proses aktivasi akun siswa.

                        <?php if(session('success')): ?>
                            <div class="p-3 bg-green-200 text-green-800 rounded mb-2">
                                Bukti pembayaran berhasil dikirim. Mohon menunggu verifikasi admin.
                            </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                            <div class="p-3 bg-red-200 text-red-800 rounded mb-2">
                                <?php echo e($errors->first()); ?>

                            </div>
                        <?php endif; ?>

                        
                        <form action="<?php echo e(route('parent.upload-pembayaran')); ?>" method="POST"
                            enctype="multipart/form-data" class="mt-4">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="regType" value="<?php echo e(request('regType')); ?>">
                            <input type="hidden" name="siswa_ids" value="<?php echo e($nonActiveStudents->pluck('id')->join(',')); ?>">

                            <div class="mb-4">
                                <label class="block mb-1 font-medium">Jumlah yang harus dibayar</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500 font-bold">Rp.</span>
                                    <input type="text"
                                        name="totalPendaftaran"
                                        value="<?php echo e(number_format($totalPendaftaran, 0, ',', '.')); ?>"
                                        readonly
                                        class="border border-gray-300 bg-gray-300 rounded-lg p-2 w-full text-sm text-gray-500 font-bold pl-10 pr-3"
                                        inputmode="numeric"
                                        autocomplete="off">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="block mb-1 font-medium">Upload Bukti Pembayaran</label>
                                <input type="file" name="bukti_pembayaran" accept="image/*" required
                                    class="border border-gray-300 bg-white rounded-lg p-2 w-full text-sm">
                            </div>

                            <button type="submit"
                                    class="bg-green-700 hover:bg-green-800 text-white font-semibold py-2 px-6 rounded-lg">
                                Verifikasi Pembayaran
                            </button>
                        </form>
                    </div>
                <?php elseif($pembayaran->status === 'pending'): ?>
                    <?php
                        $message = "Halo, Saya ingin konfirmasi pembayaran pendaftaran siswa Satria Siliwangi Basketball atas nama *$parent->name*";
                        $message .= "\n\nDengan detail sebagai berikut:";
                        $message .= "\n• Jumlah Siswa: " . $nonActiveStudents->count();
                        $message .= "\n• Nama Siswa: " . implode(', ', $nonActiveStudents->pluck('name')->toArray());
                        $message .= "\n• Jumlah Pembayaran: Rp " . number_format($totalPendaftaran, 0, ',', '.');
                        $message .= "\n• Tanggal Konfirmasi: " . $pembayaran->created_at->format('d-m-Y H:i');
                    ?>

                    <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-xl" role="alert">
                        <p class="font-bold mb-2">Menunggu Verifikasi</p>
                        <p>Bukti pembayaran Anda telah dikirim dan sedang menunggu verifikasi dari admin. Mohon tunggu proses verifikasi 1x24 jam.</p>

                        <p class="text-xs mt-4">Jika menurut anda verifikasi terlalu lama dan sudah lebih dari 1x24 jam, anda bisa menghubungi admin kami melalui tombol WhatsApp dibawah.</p>

                        <a href="https://wa.me/62895606432020?text=<?php echo e(urlencode($message)); ?>" target="_blank"
                            class="inline-flex items-center gap-2 px-5 py-1 mt-5 mb-2 bg-green-500 hover:bg-green-600 text-white font-medium rounded-full shadow">
                            <i class="fa-brands fa-whatsapp text-lg"></i> WhatsApp Admin
                        </a>
                    </div>

                <?php elseif($pembayaran->status === 'verified'): ?>
                    <div class="bg-green-100 border border-green-200 rounded-2xl p-6 text-green-900 mb-6">
                        <p class="font-semibold mb-2">Pembayaran Terverifikasi</p>
                        <p>Pembayaran / registrasi sudah diverifikasi oleh admin. Siswa siap diaktifkan.</p>

                        <?php
                            $message = "Halo Admin, saya ingin menanyakan status pendaftaran siswa atas nama *$parent->name*"
                                        . "\nJumlah Siswa: " . $nonActiveStudents->count()
                                        . "\nNama Siswa: " . implode(', ', $nonActiveStudents->pluck('name')->toArray());
                        ?>

                        <a href="https://wa.me/62895606432020?text=<?php echo e(urlencode($message)); ?>" target="_blank"
                            class="inline-flex items-center gap-2 px-5 py-2 mt-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg">
                            <i class="fa-brands fa-whatsapp text-lg"></i> WhatsApp Admin
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.jumlah-input').forEach(function(input) {
            input.addEventListener('input', function(e) {
                // Hapus karakter selain angka
                let value = e.target.value.replace(/[^\d]/g, '');

                // Format angka dengan titik ribuan
                if (value) {
                    e.target.value = value.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                } else {
                    e.target.value = '';
                }
            });

            // Saat submit form, ubah ke angka murni tanpa titik
            input.closest('form').addEventListener('submit', function() {
                input.value = input.value.replace(/\./g, '');
            });
        });
    });
    </script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/parent/dashboard.blade.php ENDPATH**/ ?>