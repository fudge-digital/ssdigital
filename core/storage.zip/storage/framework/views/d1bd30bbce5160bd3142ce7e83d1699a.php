<div class="bg-white mt-6">
    <h2 class="text-xl font-bold">Dokumen Siswa</h2>
    <p class="text-xs text-gray-400 mb-2"><span class="text-red-500 mr-2">(*)</span> Kartu Keluarga dan Akta Lahir wajib untuk di upload</p>
    
    <?php
        $dokumen = $student->profile?->documents ?? null;
    ?>

    <table class="w-full text-left text-sm">
        <?php $__currentLoopData = ['kk' => 'Kartu Keluarga', 'akta' => 'Akta Lahir', 'ijazah' => 'Ijazah', 'nisn' => 'NISN']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $required = in_array($key, ['kk','akta']); // dokumen wajib
                $existingDoc = $student->profile?->documents?->where('type', $key)->first();
            ?>
            <tr>
                <th class="py-2 px-4 border-b w-1/3 font-semibold">
                    <?php if($required): ?>
                        <span class="text-red-600 font-bold mr-2">(*)</span>
                    <?php endif; ?>
                    <?php echo e($label); ?>

                </th>

                <td class="py-2 px-4 border-b" id="<?php echo e($key); ?>-wrapper">
                    
                    <?php if(!$existingDoc): ?>
                        <span class="text-red-500 text-xs">Belum ada dokumen</span>

                        <?php if(auth()->user()->hasRole(['admin','orang_tua'])): ?>
                            <form action="<?php echo e(route('document.upload', [$student->profile->id, $key])); ?>"
                                method="POST" enctype="multipart/form-data"
                                class="inline-block ml-3">
                                <?php echo csrf_field(); ?>
                                <input type="file" name="file"
                                    class="text-sm"
                                    onchange="this.form.submit()">
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <div class="flex flex-row justify-between items-center">
                            <button onclick="openDocModal('<?php echo e(asset('storage/' . $existingDoc->file_path)); ?>')"
                                    class="text-blue-600 text-sm">
                                <i class="fa-solid fa-eye mr-1"></i> Lihat dokumen
                            </button>

                            <?php if(auth()->user()->hasRole(['admin','orang_tua'])): ?>
                                
                                <button class="bg-red-600 text-white p-1 rounded text-xs font-medium ml-4 delete-document"
                                        data-id="<?php echo e($existingDoc->id); ?>"
                                        data-type="<?php echo e($key); ?>">
                                    Hapus
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    
    <div class="mt-6">
        <h3 class="text-lg font-semibold">Dokumen Lain</h3>
        <p class="text-xs text-gray-400">Jika ada dokumen pendukung (surat pindah, surat keterangan, dll)</p>
        <?php
            $dokumenLain = $student->profile?->documents?->where('type', 'lain');
        ?>

        <table class="w-full text-left text-sm border rounded mt-3">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-2 px-3 border">Judul</th>
                    <th class="py-2 px-3 border">Aksi</th>
                </tr>
            </thead>

            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dokumenLain ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="py-2 px-3 border"><?php echo e($doc->title); ?></td>
                    <td class="py-2 px-3 border">
                        <button onclick="openDocModal('<?php echo e(asset('storage/' . $doc->file_path)); ?>')"
                                class="text-blue-600 underline text-sm">
                            Lihat
                        </button>

                        <?php if(auth()->user()->hasRole(['admin','orang_tua'])): ?>
                            <form action="<?php echo e(route('document.delete', $doc->id)); ?>"
                                method="POST" class="inline-block ml-2"
                                onsubmit="return confirm('Yakin ingin menghapus dokumen ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="text-red-600 underline text-sm">
                                    Hapus
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" class="text-center py-3 text-red-600 text-sm border">
                        Belum ada dokumen lain
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <?php if(auth()->user()->hasRole(['admin','orang_tua'])): ?>
        <div class="mt-4">
            <form action="<?php echo e(route('document.upload', [$student->profile->id, 'lain'])); ?>"
                method="POST" enctype="multipart/form-data" class="flex items-center gap-3">
                <?php echo csrf_field(); ?>

                <input type="text" name="title" placeholder="Judul dokumen"
                    class="border rounded px-2 py-1 text-sm w-1/3" required>

                <input type="file" name="file"
                    class="text-sm border rounded px-2 py-1"
                    onchange="this.form.submit()" required>
            </form>
        </div>
    <?php endif; ?>

</div>


<?php echo $__env->make('siswa.partials.documents-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
    document.addEventListener("click", function(e) {
        if (e.target.classList.contains("delete-document")) {
            let id = e.target.dataset.id;
            let type = e.target.dataset.type;

            if (!confirm("Yakin ingin menghapus dokumen ini?")) return;

            fetch(`/document/${id}`, {
                method: "DELETE",
                headers: {
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
                }
            })
            .then(res => res.json())
            .then(data => {

                document.getElementById(`${type}-wrapper`).innerHTML = `
                    <span class="text-red-500 text-xs">Belum ada dokumen</span>

                    <form action="/siswa/<?php echo e($student->profile->id); ?>/document/${type}"
                        method="POST" enctype="multipart/form-data"
                        class="inline-block ml-3">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file"
                            class="text-sm"
                            onchange="this.form.submit()">
                    </form>
                `;
            })
            .catch(err => console.error(err));
        }
    });
</script>
<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/siswa/partials/documents.blade.php ENDPATH**/ ?>