

<?php $__env->startSection('title', 'Verifikasi Pembayaran Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">

    <h2 class="text-2xl font-bold mb-6 text-gray-800">Verifikasi Pembayaran Pendaftaran</h2>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 border border-green-300 px-4 py-3 rounded-lg mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 border border-red-300 px-4 py-3 rounded-lg mb-6">
            <?php echo e(implode(', ', $errors->all())); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white shadow rounded-2xl overflow-hidden border border-gray-200">
        <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-gray-50 border-b text-gray-900 font-semibold">
                <tr>
                    <th class="px-4 py-3 text-left">#</th>
                    <th class="px-4 py-3 text-left">Orang Tua</th>
                    <th class="px-4 py-3 text-left">Anak Terdaftar</th>
                    <th class="px-4 py-3 text-left">Jumlah Pembayaran</th>
                    <th class="px-4 py-3 text-left">Jenis Pembayaran</th>
                    <th class="px-4 py-3 text-left">Status</th>
                    <th class="px-4 py-3 text-left">Bukti Pembayaran</th>
                    <th class="px-4 py-3 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-3"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-3">
                            <div class="font-semibold"><?php echo e($p->user->name); ?></div>
                            <div class="text-xs text-gray-500"><?php echo e($p->user->email); ?></div>
                        </td>
                        <td class="px-4 py-3">
                            <?php if($p->details->count() > 0): ?>
                                <ul class="list-disc list-inside text-xs text-gray-600">
                                    <?php $__currentLoopData = $p->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('siswa.show', $detail->siswa->id)); ?>">
                                            <?php echo e($detail->siswa->name); ?>

                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php elseif($p->siswa): ?>
                                <?php echo e($p->siswa->name); ?>

                            <?php else: ?>
                                <span class="text-gray-400 italic">Tidak ada data</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 font-semibold">
                            <?php if(number_format($p->jumlah_total, 0, ',', '.')): ?>
                                Rp <?php echo e(number_format($p->jumlah_total, 0, ',', '.')); ?>

                            <?php else: ?>
                                <p>-</p>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 capitalize"><?php echo e(str_replace('_',' ', $p->jenis)); ?></td>
                        <td class="px-4 py-3">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold <?php echo e($p->status_badge_class); ?>">
                                <?php echo e($p->status_label); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <?php
                                $fileUrl = $p->bukti_pembayaran
                                    ? asset('storage/' . $p->bukti_pembayaran)
                                    : null;
                            ?>

                            <?php if($fileUrl): ?>
                            <button
                                data-modal-target="previewModal"
                                data-modal-toggle="previewModal"
                                onclick="setPreviewContent(<?php echo \Illuminate\Support\Js::from($fileUrl)->toHtml() ?>)"
                                class="bg-blue-500 text-white hover:bg-blue-600 text-xs px-3 py-1 rounded-xl">
                                Lihat Bukti Pembayaran
                            </button>
                            <?php else: ?>
                                <span class="bg-gray-500 text-white text-xs px-3 py-1 rounded-xl">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-center space-x-2">
                            <?php if($p->status !== 'verified'): ?>
                                <!-- Button trigger modal -->
                                <button
                                    class="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1 rounded-lg"
                                    onclick="openVerifyModal(<?php echo e($p->id); ?>)">
                                    Verifikasi
                                </button>

                                <!-- Modal -->
                                <div id="verifyModal-<?php echo e($p->id); ?>" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                                    <div class="bg-white rounded-xl shadow-lg w-96 p-6">
                                        <h2 class="text-lg font-semibold mb-4">Konfirmasi Verifikasi</h2>
                                        <p class="mb-6">Apakah Anda yakin ingin memverifikasi pembayaran ini?</p>
                                        
                                        <div class="flex justify-end space-x-3">
                                            <button
                                                onclick="closeVerifyModal(<?php echo e($p->id); ?>)"
                                                class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg">
                                                Batal
                                            </button>

                                            <form action="<?php echo e(route('admin.pembayaran.verify', $p->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg">
                                                    Lanjutkan
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if($p->status === 'verified'): ?>
                                <form action="<?php echo e(route('admin.pembayaran.suspend', $p->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="bg-yellow-500 hover:bg-yellow-600 text-white text-xs px-3 py-1 rounded-lg">
                                        Suspensi
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <div id="previewModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed inset-0 z-50 bg-black bg-opacity-60 flex justify-center items-center">
                        <div class="relative p-4 w-full max-w-3xl max-h-[85vh]">
                            <div class="relative bg-white rounded-lg shadow-lg overflow-hidden">
                                
                                <!-- Header -->
                                <div class="flex items-center justify-between p-4 border-b">
                                    <h3 class="text-lg font-semibold">Preview Bukti Pembayaran</h3>
                                    <button type="button" data-modal-hide="previewModal"
                                            class="text-gray-500 hover:text-gray-700 text-2xl font-bold">✕</button>
                                </div>

                                <!-- Content -->
                                <div id="modalContent" class="p-4 overflow-y-auto max-h-[75vh]">
                                    <!-- dynamic content -->
                                </div>
                                
                                <div id="modalFooter" class="p-4 border-t text-right">
                                    <a href="<?php echo e($fileUrl); ?>" target="_blank" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg">
                                        <i class="fa-solid fa-arrow-up-right-from-square"></i> Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-gray-500 py-6">Belum ada data pembayaran.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function setPreviewContent(url) {
        const content = document.getElementById("modalContent");
        const ext = url.split('.').pop().toLowerCase();

        if (['jpg','jpeg','png','gif','webp'].includes(ext)) {
            content.innerHTML = `<img src="${url}" class="w-full max-h-[70vh] object-contain rounded" />`;
        } else if (ext === 'pdf') {
            content.innerHTML = `<embed src="${url}" type="application/pdf" class="w-full h-[70vh]" />`;
        } else {
            content.innerHTML = `<p class="text-gray-500">Format tidak didukung</p>`;
        }
    }
</script>

<script>
    function openVerifyModal(id) {
        document.getElementById(`verifyModal-${id}`).classList.remove('hidden');
    }

    function closeVerifyModal(id) {
        document.getElementById(`verifyModal-${id}`).classList.add('hidden');
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faza adzima\Documents\PROJECT\ss\core\resources\views/admin/pembayaran/index.blade.php ENDPATH**/ ?>