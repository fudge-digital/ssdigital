<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Verifikasi Pembayaran Berhasil</title>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family:'Barlow',sans-serif;background:#f5f7fa;color:#333;margin:0;padding:0; }
        .container { max-width:600px;background:#fff;margin:40px auto;border-radius:12px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.1); }
        .header { background:#0d5133;color:#fff;text-align:center;padding:20px; }
        .header img { height:80px;margin-bottom:0; }
        .content { padding:25px;font-size:14px; }
        .table { width:100%;border-collapse:collapse;margin-top:15px; }
        .table th,.table td { border-bottom:1px solid #eee;padding:8px 5px;text-align:left; }
        .footer { background:#f1f1f1;text-align:center;font-size:12px;padding:15px;color:#555; }
        .btn { background:#0d5133;color:white;padding:10px 18px;border-radius:30px;text-decoration:none;font-weight:bold; }
    </style>
</head>

<body>
<div class="container">
    <div class="header">
        <img src="{{ asset('images/SATRIASILIWANGIFONT-1.png') }}" alt="Logo Klub">
        <h3>Pembayaran Diverifikasi</h3>
    </div>

    <div class="content">

        <p>Halo <strong>{{ $parent->name }}</strong>,</p>
        <p>Pembayaran Anda telah berhasil diverifikasi oleh admin.</p>

        <h4>Detail Siswa</h4>

        <table class="table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Kelompok Umur</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($students as $detail)
                    <tr>
                        <td>{{ $detail->siswa->name }}</td>
                        <td>{{ $detail->siswa->siswaProfile->kategori_umur ?? '-' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        @if($pembayaran->jenis === 'pendaftaran_baru')
            <h4 style="margin-top:20px;">Total Pembayaran</h4>
            <p><strong>Rp {{ number_format($pembayaran->jumlah_total, 0, ',', '.') }}</strong></p>
        @endif

        <div style="text-align:center;margin-top:25px;">
            <a class="btn" href="{{ route('parent.dashboard') }}">Cek Dashboard</a>
        </div>
    </div>

    <div class="footer">
        &copy; {{ date('Y') }} Satria Siliwangi Basketball. Semua hak dilindungi.
    </div>
</div>
</body>
</html>
